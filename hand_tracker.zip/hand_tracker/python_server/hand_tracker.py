import cv2
import mediapipe as mp
import socketio
import numpy as np
from config import SERVER_HOST, SERVER_PORT, CONFIDENCE_THRESHOLD
import json
import time

class HandTracker:
    def __init__(self):
        # Initialize MediaPipe Hands
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            min_detection_confidence=CONFIDENCE_THRESHOLD,
            min_tracking_confidence=CONFIDENCE_THRESHOLD
        )
        self.mp_draw = mp.solutions.drawing_utils
        
        # Initialize Socket.IO
        self.sio = socketio.Server()
        self.app = socketio.WSGIApp(self.sio)
        
        # Track previous positions for smoothing
        self.prev_positions = {}
        
        # Setup Socket.IO events
        self.sio.on('connect', self.on_connect)
        self.sio.on('disconnect', self.on_disconnect)
        
    def on_connect(self, sid, environ):
        print(f"Client connected: {sid}")
        
    def on_disconnect(self, sid):
        print(f"Client disconnected: {sid}")
    
    def smooth_position(self, hand_id, current_pos):
        """Apply smoothing to hand positions"""
        if hand_id not in self.prev_positions:
            self.prev_positions[hand_id] = current_pos
            return current_pos
        
        alpha = 0.7  # Smoothing factor
        smoothed = {}
        for key in current_pos:
            prev = self.prev_positions[hand_id].get(key, current_pos[key])
            smoothed[key] = alpha * current_pos[key] + (1 - alpha) * prev
        
        self.prev_positions[hand_id] = smoothed        return smoothed
    
    def extract_hand_data(self, hand_landmarks, hand_id):
        """Extract relevant data from hand landmarks"""
        if not hand_landmarks:
            return None
        
        # Get key points
        landmarks = hand_landmarks.landmark
        
        # Wrist position (landmark 0)
        wrist = landmarks[0]
        
        # Index finger tip (landmark 8)
        index_tip = landmarks[8]
        
        # Middle finger tip (landmark 12)
        middle_tip = landmarks[12]
        
        # Thumb tip (landmark 4)
        thumb_tip = landmarks[4]
        
        # Calculate distances
        index_middle_dist = np.sqrt(
            (index_tip.x - middle_tip.x)**2 + 
            (index_tip.y - middle_tip.y)**2
        )
        
        thumb_index_dist = np.sqrt(
            (thumb_tip.x - index_tip.x)**2 + 
            (thumb_tip.y - index_tip.y)**2
        )
        
        # Detect pinch gesture
        is_pinch = thumb_index_dist < 0.05
        
        # Detect fist (all fingers curled)
        is_fist = index_middle_dist < 0.05
        
        data = {
            'hand_id': hand_id,
            'wrist': {'x': wrist.x, 'y': wrist.y, 'z': wrist.z},
            'index_tip': {'x': index_tip.x, 'y': index_tip.y, 'z': index_tip.z},
            'gesture': 'pinch' if is_pinch else ('fist' if is_fist else 'open'),
            'confidence': hand_landmarks.landmark[0].visibility if hasattr(hand_landmarks.landmark[0], 'visibility') else 1.0,
            'timestamp': time.time()
        }
        
        return data
        def process_frame(self, frame):
        """Process video frame and detect hands"""
        # Convert BGR to RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Process the frame
        results = self.hands.process(rgb_frame)
        
        hand_data = []
        
        if results.multi_hand_landmarks:
            for hand_id, hand_landmarks in enumerate(results.multi_hand_landmarks):
                # Draw landmarks
                self.mp_draw.draw_landmarks(
                    frame, 
                    hand_landmarks, 
                    self.mp_hands.HAND_CONNECTIONS
                )
                
                # Extract data
                data = self.extract_hand_data(hand_landmarks, hand_id)
                if data:
                    smoothed_data = self.smooth_position(hand_id, data)
                    hand_data.append(smoothed_data)
        
        return frame, hand_data
    
    def broadcast_data(self, hand_data):
        """Send hand data to all connected clients"""
        if hand_data:
            self.sio.emit('hand_data', hand_data)
    
    def run(self):
        """Main loop"""
        # Start camera
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("Error: Cannot open camera")
            return
        
        print(f"Server running on {SERVER_HOST}:{SERVER_PORT}")
        print("Press 'q' to quit")
        
        # Start Socket.IO server in background
        import threading
        server_thread = threading.Thread(
            target=lambda: socketio.run(self.app, host=SERVER_HOST, port=SERVER_PORT)
        )
        server_thread.daemon = True        server_thread.start()
        
        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                # Process frame
                processed_frame, hand_data = self.process_frame(frame)
                
                # Broadcast data
                self.broadcast_data(hand_data)
                
                # Display frame
                cv2.putText(processed_frame, f"Hands: {len(hand_data)}", 
                           (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                cv2.imshow('Hand Tracker', processed_frame)
                
                # Check for quit
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                    
        finally:
            cap.release()
            cv2.destroyAllWindows()
            self.hands.close()

if __name__ == "__main__":
    tracker = HandTracker()
    tracker.run()