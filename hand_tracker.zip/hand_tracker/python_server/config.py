# Network Configuration
SERVER_HOST = '0.0.0.0'  # Listen on all interfaces
SERVER_PORT = 5000

# Hand Tracking Configuration
CONFIDENCE_THRESHOLD = 0.5
TRACKING_SMOOTHING = 0.5  # 0-1, higher = smoother