package com.example.handtracker

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONArray
import java.net.URI

class MainActivity : AppCompatActivity() {
    
    private lateinit var textView: TextView
    private var socket: Socket? = null
    private val SERVER_URL = "http://YOUR_COMPUTER_IP:5000" // Replace with your IP
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        textView = TextView(this).apply {
            textSize = 16f
            setPadding(20, 20, 20, 20)
        }
        setContentView(textView)
        
        connectToServer()
    }
    
    private fun connectToServer() {
        try {
            socket = IO.socket(URI(SERVER_URL))
            
            socket?.on(Socket.EVENT_CONNECT) {
                runOnUiThread {
                    Toast.makeText(this, "Connected to server", Toast.LENGTH_SHORT).show()
                }
            }
            
            socket?.on("hand_data") { args ->
                val data = args[0] as JSONArray
                runOnUiThread {
                    updateDisplay(data)
                }
            }
            
            socket?.on(Socket.EVENT_DISCONNECT) {
                runOnUiThread {
                    Toast.makeText(this, "Disconnected from server", Toast.LENGTH_SHORT).show()
                }
            }
            
            socket?.connect()
            
        } catch (e: Exception) {
            e.printStackTrace()
            runOnUiThread {
                Toast.makeText(this, "Connection failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
    
    private fun updateDisplay(data: JSONArray) {
        val sb = StringBuilder()
        sb.append("Hands Detected: ${data.length()}\n\n")
        
        for (i in 0 until data.length()) {
            val hand = data.getJSONObject(i)
            sb.append("Hand ${hand.getInt("hand_id")}: ")
            sb.append("Gesture: ${hand.getString("gesture")}\n")
            
            val wrist = hand.getJSONObject("wrist")
            sb.append("Wrist: X=${String.format("%.2f", wrist.getDouble("x"))}, ")
            sb.append("Y=${String.format("%.2f", wrist.getDouble("y"))}\n")
            
            val confidence = hand.getDouble("confidence")
            sb.append("Confidence: ${String.format("%.2f", confidence)}\n")
            sb.append("---\n")
        }
        
        textView.text = sb.toString()
    }
    
    override fun onDestroy() {
        super.onDestroy()
        socket?.disconnect()
        socket?.close()
    }
}