# 🖐️ Hand Tracking System - Python to Android

[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/)
[![Android](https://img.shields.io/badge/Android-5.0+-green.svg)](https://www.android.com/)
[![MediaPipe](https://img.shields.io/badge/MediaPipe-0.10.0-orange.svg)](https://google.github.io/mediapipe/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

A real-time hand tracking and gesture recognition system that connects Python computer vision with Android devices. Track hand movements, detect gestures, and stream data wirelessly between devices.

---

## 📋 Table of Contents

- [Features](#-features)
- [Demo](#-demo)
- [Project Structure](#-project-structure)
- [Prerequisites](#-prerequisites)
- [Installation](#-installation)
- [Usage](#-usage)
- [API Reference](#-api-reference)
- [Troubleshooting](#-troubleshooting)
- [Contributing](#-contributing)
- [License](#-license)

---

## ✨ Features

- 🎯 **Real-time Hand Tracking** - Track up to 2 hands simultaneously
- 👆 **Gesture Recognition** - Detect pinch, fist, and open hand gestures
- 📱 **Android Integration** - Stream data to Android devices via WebSocket
- 🐍 **Termux Support** - Run directly on Android using Termux
- 🌐 **Web Interface** - View processed video in browser
- 📊 **Confidence Scoring** - Get accuracy metrics for each detection
- 🎨 **Visual Feedback** - See landmarks drawn on video feed
- ⚡ **Low Latency** - Optimized for real-time performance

---

## 🎬 Demo

| Desktop + Android | Termux Only |
|:---:|:---:|
| ![Desktop Demo](assets/demo_desktop.gif) | ![Termux Demo](assets/demo_termux.gif) |

*Gestures detected: Pinch 👌, Fist ✊, Open Hand 🖐️*

---

## 📁 Project Structure

```
hand_tracker/
├── python_server/
│   ├── hand_tracker.py          # Main hand tracking script
│   ├── config.py                # Configuration settings
│   └── requirements.txt         # Python dependencies
├── android_app/
│   ├── MainActivity.kt          # Android app main activity
│   ├── AndroidManifest.xml      # App permissions
│   └── build.gradle             # Android dependencies
├── termux/
│   ├── hand_tracker_termux.py   # Termux-compatible version
│   └── setup_termux.sh          # Termux setup script
├── assets/
│   └── demo_*.gif               # Demo screenshots
├── README.md                    # This file
└── LICENSE                      # MIT License
```

---

## 🛠 Prerequisites

### For Desktop + Android Setup
- Python 3.8 or higher
- Android 5.0 or higher
- Webcam
- Same WiFi network for both devices

### For Termux Setup
- Android 5.0 or higher
- Termux app from F-Droid (not Play Store)
- IP Webcam app
- Storage permission for Termux

---

## 📥 Installation

### Option 1: Desktop + Android

#### 1. Clone the Repository
```bash
git clone https://github.com/eilyasaraz1-sketch/hand-tracker.git
cd hand-tracker
```

#### 2. Install Python Dependencies
```bash
cd python_server
pip install -r requirements.txt
```

#### 3. Setup Android App
- Open `android_app/` in Android Studio
- Update `SERVER_URL` in `MainActivity.kt` with your computer's IP
- Build and install on your Android device

### Option 2: Termux Only (Android)

#### 1. Install Termux
Download from [F-Droid](https://f-droid.org/en/packages/com.termux/)

#### 2. Run Setup Script
```bash
pkg update && pkg upgrade
pkg install python cmake clang libjpeg-turbo libpng
pip install opencv-python-headless mediapipe flask
```

#### 3. Install IP Webcam
- Download from [Play Store](https://play.google.com/store/apps/details?id=com.pas.webcam)
- Start server and note the URL

---

## 🚀 Usage

### Desktop + Android Mode

#### 1. Start Python Server
```bash
cd python_server
python hand_tracker.py
```

#### 2. Find Your IP Address
```bash
# Windows
ipconfig

# Mac/Linux
ifconfig
```

#### 3. Configure Android App
Edit `MainActivity.kt`:
```kotlin
val SERVER_URL = "http://192.168.1.100:5000" // Your computer's IP
```

#### 4. Launch Android App
- Ensure both devices are on same WiFi
- Open the Android app
- You should see hand tracking data in real-time

### Termux Mode

#### 1. Start IP Webcam
- Open IP Webcam app
- Tap "Start Server"
- Note the URL (e.g., `http://127.0.0.1:8080`)

#### 2. Run Python Script
```bash
python hand_tracker_termux.py
```

#### 3. Open Browser
Navigate to: `http://127.0.0.1:5000`

---

## 🔌 API Reference

### WebSocket Events

| Event | Direction | Data Format | Description |
|-------|-----------|-------------|-------------|
| `connect` | Client → Server | - | Client connects to server |
| `disconnect` | Client → Server | - | Client disconnects |
| `hand_data` | Server → Client | JSON Array | Hand tracking data |

### Hand Data Structure
```json
{
  "hand_id": 0,
  "wrist": {"x": 0.5, "y": 0.6, "z": 0.1},
  "index_tip": {"x": 0.5, "y": 0.4, "z": 0.1},
  "gesture": "pinch",
  "confidence": 0.95,
  "timestamp": 1699000000.0
}
```

### Configuration Options

```python
# config.py
SERVER_HOST = '0.0.0.0'      # Network interface
SERVER_PORT = 5000           # Server port
CONFIDENCE_THRESHOLD = 0.5   # Detection confidence (0-1)
TRACKING_SMOOTHING = 0.7     # Position smoothing (0-1)
```

---

## 🐛 Troubleshooting

| Problem | Solution |
|---------|----------|
| **Cannot connect to server** | Check firewall settings, allow port 5000 |
| **Camera not detected** | Ensure webcam is connected and permissions granted |
| **High latency** | Reduce video resolution, lower `CONFIDENCE_THRESHOLD` |
| **Termux camera fails** | Use IP Webcam app instead of direct camera access |
| **`cv2.imshow` crashes** | Don't use in Termux, use Flask web interface |
| **MediaPipe installation fails** | Try `pip install mediapipe==0.10.0` |
| **Android app won't connect** | Verify both devices on same WiFi network |

### Common Errors

```bash
# Error: Port already in use
# Solution: Change SERVER_PORT in config.py

# Error: Permission denied (Termux)
# Solution: pkg install termux-api && termux-setup-storage

# Error: Module not found
# Solution: pip install -r requirements.txt --upgrade
```

---

## 🤝 Contributing

We welcome contributions! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

### Development Guidelines
- Follow PEP 8 for Python code
- Use meaningful commit messages
- Add tests for new features
- Update documentation as needed

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

```
MIT License

Copyright (c) 2024 eilyas araz

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
```

---

## 📧 Contact

- **Author:** eilyas araz
- **Email:** eilyasaraz1@gmail.com
- **GitHub:** [@eilyasaraz1-sketch](https://github.com/eilyasaraz1-sketch)

---

## 🙏 Acknowledgments

- [MediaPipe](https://google.github.io/mediapipe/) - Hand tracking solution
- [OpenCV](https://opencv.org/) - Computer vision library
- [Socket.IO](https://socket.io/) - Real-time communication
- [Flask](https://flask.palletsprojects.com/) - Web framework
- [Termux](https://termux.dev/) - Android terminal emulator

---

## 📊 Performance Benchmarks

| Device | FPS | Latency | CPU Usage |
|--------|-----|---------|-----------|
| Desktop (i7) | 30 | 50ms | 40% |
| Android (Snapdragon) | 15 | 100ms | 60% |
| Termux (Mid-range) | 10 | 150ms | 70% |

*Tested with 640x480 resolution, 2 hands tracking*

---

## 🗺️ Roadmap

- [ ] Add more gesture types (wave, swipe, etc.)
- [ ] Implement hand gesture controls for apps
- [ ] Add multi-device support
- [ ] Create iOS version
- [ ] Add machine learning for custom gestures
- [ ] Improve Termux performance
- [ ] Add voice commands
- [ ] Create Unity integration

---

<div align="center">

**Made with ❤️ by eilyas araz**

[⬆ Back to Top](#-hand-tracking-system---python-to-android)

</div>